# Mr Cool Mouth Freshener Website

A beginner-friendly, responsive static website built with plain HTML, CSS, and JavaScript.

## Project files

- `index.html` — Home page
- `shop.html` — Single product page
- `contact.html` — Contact details and frontend-only message form
- `enquiry.html` — Wholesale and retail enquiry form
- `cart.html` — Local browser cart
- `style.css` — Shared responsive styles
- `script.js` — Navigation, cart, price setting, and form behavior
- `assets/mr-cool-product.png` — Supplied Mr Cool reference image used for product visuals

## Run locally

Open `index.html` in a modern browser. For a local web server, open a terminal in this folder and run `python -m http.server 8000`, then visit `http://localhost:8000`.

## Edit the price and description

Open `script.js` and update the `PRODUCT` object near the top. Set `price` to a number (for example `199`) to show the price and calculate cart subtotals. It is `null` by default because no price was provided. Edit the description text in `shop.html` and `index.html` directly.

## Replace the product image and add the original video

Replace `assets/mr-cool-product.png` with your own product image using the same filename. The current asset is the supplied brand reference image showing the product. No original video file was included among the available attachments. To use it as a live hero background, copy your original video to `assets/mr-cool-video.mp4`, then add this inside the `.hero` section in `index.html` before `.hero-shade`:

```html
<video class="hero-video" autoplay muted loop playsinline poster="assets/mr-cool-product.png">
  <source src="assets/mr-cool-video.mp4" type="video/mp4">
</video>
```

Add this CSS rule to `style.css`:

```css
.hero-video { position:absolute; inset:0; width:100%; height:100%; object-fit:cover; }
```

Keep the poster as a fallback for browsers that cannot play the video.

## Upload to GitHub

1. Create a new repository on GitHub.
2. Extract or open this project folder.
3. In a terminal in the project folder, run `git init`, `git add .`, `git commit -m "Create Mr Cool website"`, `git branch -M main`, and `git remote add origin YOUR_REPOSITORY_URL`.
4. Run `git push -u origin main`.

## Publish with GitHub Pages

1. In the repository, open **Settings → Pages**.
2. Under the build/deploy source, choose **Deploy from a branch**.
3. Select `main` and `/ (root)` and save.
4. Wait for GitHub Pages to publish, then open the URL shown on the Pages settings screen.

## Links and form behavior

The website Buy Now links open `https://mrcool-hj483p.my.canva.site/` in a new tab. The cart checkout opens `https://rzp.io/rzp/DqYpkDNM` in a new tab. Contact and enquiry forms are frontend-only and do not send or store submissions; connect them to a backend or form service before relying on them to receive messages. The cart stores its single product quantity in browser localStorage.
