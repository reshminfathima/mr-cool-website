// Mr Cool site settings. Replace the placeholder value when the product price is confirmed.
const PRODUCT = {
  name: "Mr Cool Mouth Freshener",
  price: null, // Example: 199. Use a number to show the price and calculate subtotals.
  image: "assets/mr-cool-product.png"
};
const BUY_NOW_URL = "https://mrcool-hj483p.my.canva.site/";
const CART_CHECKOUT_URL = "https://rzp.io/rzp/DqYpkDNM";
const CART_KEY = "mrCoolCart";

function getCart() {
  try { return JSON.parse(localStorage.getItem(CART_KEY)) || { quantity: 0 }; }
  catch { return { quantity: 0 }; }
}
function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify({ quantity: Math.max(0, Number(cart.quantity) || 0) }));
  updateCartCount();
}
function updateCartCount() {
  const quantity = getCart().quantity;
  document.querySelectorAll(".cart-count").forEach((badge) => { badge.textContent = quantity; });
}
function setYear() {
  document.querySelectorAll(".year").forEach((el) => { el.textContent = new Date().getFullYear(); });
}
function initNavigation() {
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".main-nav");
  if (!toggle || !nav) return;
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
  });
}
function initQuantity() {
  const input = document.querySelector("#shop-quantity");
  if (!input) return;
  document.querySelectorAll("[data-qty]").forEach((button) => {
    button.addEventListener("click", () => {
      const current = Math.max(1, parseInt(input.value, 10) || 1);
      input.value = button.dataset.qty === "plus" ? current + 1 : Math.max(1, current - 1);
    });
  });
  input.addEventListener("change", () => { input.value = Math.max(1, parseInt(input.value, 10) || 1); });
  document.querySelector("#add-to-cart")?.addEventListener("click", () => {
    const cart = getCart();
    cart.quantity += Math.max(1, parseInt(input.value, 10) || 1);
    saveCart(cart);
    const button = document.querySelector("#add-to-cart");
    button.innerHTML = "Added to Cart <span>✓</span>";
    window.setTimeout(() => { button.innerHTML = "Add to Cart <span>＋</span>"; }, 1500);
  });
}
function formatPrice(amount) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(amount);
}
function renderCart() {
  const root = document.querySelector("#cart-content");
  if (!root) return;
  const cart = getCart();
  if (!cart.quantity) {
    root.innerHTML = `<div class="empty-cart"><h2>Your cart is empty</h2><p>Explore the Mr Cool blend and add it to your cart.</p><a class="button" href="shop.html">Go to Shop <span>→</span></a></div>`;
    return;
  }
  const subtotal = PRODUCT.price === null ? "Price to be updated" : formatPrice(PRODUCT.price * cart.quantity);
  const unitPrice = PRODUCT.price === null ? "Price to be updated" : formatPrice(PRODUCT.price);
  root.innerHTML = `<div class="cart-row"><img src="${PRODUCT.image}" alt="Mr Cool Mouth Freshener"><div><h2>${PRODUCT.name}</h2><p>${unitPrice} each</p><div class="cart-controls"><button type="button" data-cart-action="minus" aria-label="Decrease quantity">−</button><strong>${cart.quantity}</strong><button type="button" data-cart-action="plus" aria-label="Increase quantity">+</button><button type="button" data-cart-action="remove" class="remove-button">Remove</button></div></div><div class="cart-subtotal"><small>Subtotal</small><br><strong>${subtotal}</strong></div></div><div class="cart-total"><span>Total</span><span>${subtotal}</span></div><div class="cart-actions"><a class="button button-outline" href="shop.html">Continue Shopping</a><a class="button" href="${CART_CHECKOUT_URL}" target="_blank" rel="noopener noreferrer">Continue to Checkout <span>↗</span></a></div><p class="hint" style="text-align:right;margin-top:14px">Checkout opens Razorpay. Payment status is handled by the payment provider.</p>`;
  root.querySelectorAll("[data-cart-action]").forEach((button) => {
    button.addEventListener("click", () => {
      const current = getCart();
      if (button.dataset.cartAction === "plus") current.quantity += 1;
      if (button.dataset.cartAction === "minus") current.quantity = Math.max(1, current.quantity - 1);
      if (button.dataset.cartAction === "remove") current.quantity = 0;
      saveCart(current);
      renderCart();
    });
  });
}
function initForms() {
  document.querySelectorAll("[data-frontend-form]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      window.alert("This form is frontend-only and is not connected to a submission service. Please contact us using the details shown on this page.");
    });
  });
}
document.addEventListener("DOMContentLoaded", () => {
  updateCartCount(); setYear(); initNavigation(); initQuantity(); renderCart(); initForms();
  document.querySelectorAll("[data-price]").forEach((el) => { if (PRODUCT.price !== null) el.textContent = formatPrice(PRODUCT.price); });
});
